export PYTHONPATH=${PYTHONPATH}:/Users/vijetavamannayak/LinkedInProject/scripts/utility/
export PYTHONPATH=${PYTHONPATH}:/Users/vijetavamannayak/LinkedInProject/scripts/master/
python3 /Users/vijetavamannayak/LinkedInProject/scripts/driver/driver.py config_file=/Users/vijetavamannayak/LinkedInProject/scripts/driver/driver.json